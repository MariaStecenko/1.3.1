N = int(input("N = "))

a = 1
while a < N:
    a = a * 3

print(a)
