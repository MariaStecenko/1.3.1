x = 1
eval('print(x)')

y = 3
eval('print(x + y)')
