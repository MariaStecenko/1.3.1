class MyClass:

    def __init__(self, value):
        self.value = value

    def print(self):
        print(self.value)


0