class MyClass:
    pass